__________________________

4 IN 1 CARTOON & VECTOR ART PHOTOSHOP ACTION
__________________________

Ready to use in Photoshop!These effects are excellent for photographers, graphic designers and artists. These effects are exclusively designed to enhance & upgrade your images to the next level.

INSTRUCTIONS:
__________________________

-Open Photoshop Window menu select Actions , left click on right corner of Actions panel window and select load actions
-Select action and click the Play button

FEATURES
__________________________

-One click to apply an amazing effects on your photo.
-Clean actions, Clean work.
-Easy to use.
-Cartoon Painting, Cartoon Effects, Vector Art, Color Halftone style actions.
-Cartoon Effects and Vector Art Actions Works with oil paint plug-in.
-Editable Layers

INCLUDED
__________________________

-One .atn file.
-Help file(pdf) included.

NOTE
__________________________

Be sure your Photoshop set to RGB color, 8Bits/Channel, English version.
If you are not using English version then you can change it to English.

https://www.youtube.com/watch?v=GJAiu5W2gLE


CARTOON PAINTING PHOTOSHOP ACTION
__________________________

CARTOON EFFECTS PHOTOSHOP ACTION
__________________________

VECTOR ART PHOTOSHOP ACTION
__________________________

COLOR HALFTONE PHOTOSHOP ACTION
__________________________


Thanks...

RIDVAN PARS

